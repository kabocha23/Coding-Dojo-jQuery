$("#click").click(function() {
	alert("This JQ function works!");
});
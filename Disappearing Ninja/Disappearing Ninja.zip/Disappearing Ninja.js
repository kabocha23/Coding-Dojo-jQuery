$(document).ready(function() {

	$("#ninja_pic11").click(function() {
		$("#ninja_pic11").hide("slow", function() {
		});
	});
	$("#ninja_pic12").click(function() {
		$("#ninja_pic12").hide("slow", function() {
		});
	});
	$("#ninja_pic13").click(function() {
		$("#ninja_pic13").hide("slow", function() {
		});
	});
	$("#ninja_pic14").click(function() {
		$("#ninja_pic14").hide("slow", function() {
		});
	});
	$("#ninja_pic21").click(function() {
		$("#ninja_pic21").hide("slow", function() {
		});
	});
	$("#ninja_pic22").click(function() {
		$("#ninja_pic22").hide("slow", function() {
		});
	});
	$("#ninja_pic23").click(function() {
		$("#ninja_pic23").hide("slow", function() {
		});
	});
	$("#ninja_pic24").click(function() {
		$("#ninja_pic24").hide("slow", function() {
		});
	});

	$("#restore_all_butt").click(function() {
		$(".restore").show("slow", function() {
		})
	})

});